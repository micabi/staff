--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `master_staff`
--

CREATE TABLE `master_staff` (
  `code` int(11) NOT NULL,
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `master_staff`
--

INSERT INTO `master_staff` (`code`, `name`, `password`) VALUES
(4, 'みかん', '07af613eea059030daaed3bde1fd1ce7'),
(5, 'ワタル', '5793676373f03f242ee1e7da1bcac0ff'),
(6, 'カルビ', '20fc9517961a4d011f1aeccb242bed87'),
(7, 'みきぷ', '327f8ee88942fc12e6833fb9703c841d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `master_staff`
--
ALTER TABLE `master_staff`
  ADD PRIMARY KEY (`code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `master_staff`
--
ALTER TABLE `master_staff`
  MODIFY `code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
